<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="pop-up.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <!-- buat akun start-->
    <div class="pop-up">
        <span class="close" onclick="closePopup()">&times;</span>
        <div class="np"> <h1>Buat Akun</h1></div>
            <div class="isi">
                <div class="input">
                    <input type="text" class="input" placeholder="Nama depan"/> <input type="text" class="input" placeholder="Nama belakang">
                </div>
                <div class="input">
                    <input type="email" class="input" placeholder="Alamat email">
                </div>
                <div class="input">
                    <input type="password" class="input" placeholder="Password">
                </div>
                <div class="input">
                    <input type="password" class="input" placeholder="Ketik ulang Password">
                </div>
                <div class="input">
                    <input type="text" class="input" placeholder="ID Admin">
                </div>
            </div>
            <a href="popup-login.php" class="btn-popup">Kirim</a>
            <div class="login"> 
                <p class="opt"><a href="popup-login.php">Login</a></p>
            </div>
        </div>
        <!-- buat akun end-->
</body>
</html>