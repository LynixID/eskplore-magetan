<section id="navbar">
    <div class="logo">
        <a href="">
            <img src="asset/img.hero/Logo.png" alt="Magetan" width="100px" /></a>
    </div>
    <div class="menu">
        <ul>
            <li><a href="#beranda" id="satu" class="satu">Beranda</a></li>
            <li><a href="">Galeri</a></li>
            <li><a href="#peta">Peta</a></li>
            <li><a href="">Feedback</a></li>
            <li class="cursor-pointer"><a href="#beranda" id="admin" class="relative"><input type="checkbox"
                        class="w-full h-full absolute opacity-0 cursor-pointer">Admin</a></li>
        </ul>
    </div>
</section>
