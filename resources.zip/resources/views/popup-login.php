<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="C:\Users\SDN BOGOARUM\Desktop\eskplore-magetan\resources\css\pop-up.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
    <!-- login start-->
    <div class ="pop-up">
        <span class="close" onclick="closePopup()">&times;</span>
        <div class="np"><h1>Login</h1></div><br>
        <div class="isi"></div>
        <div class="input">
            <i class='bx bxs-user'></i>
            <input type="text" class="input" placeholder="Username">
        </div>
        <div class="input">
            <i class='bx bxs-id-card'></i>
            <input type="text" class="input" placeholder="ID Admin"/>
        </div>
        <div class="input">
            <i class='bx bx-key' ></i>
            <input type="password" class="input" placeholder="Password"/>    
        </div>
        
        <div class="pw">
            <p class="opt"><a href="popup-gantipw.php">Lupa password</a></p>
        </div>
        <a href="berandaadmin.blade.php" class="btn-popup">Masuk</a>
        <div class="buat-akun">
            <p class="opt"><a href="popup-buat.php">Buat akun</a></p>
        </div>
    </div>
    <!-- login end-->
</body>
</html>
