<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="pop-up.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <!-- verif email start-->
    <div class="pop-up">
        <span class="close" onclick="closePopup()">&times;</span>
        <div class="np"><h1>Verifikasi Email</h1></div>
    <div class="isi">
        <div class="input">
            <input type="email" class="input" placeholder="Alamat email">
        </div>
        <div class="input">
            <input type="text" class="input" placeholder="Kode verifikasi">
        </div>
    </div>
    <a href="popup-login.php" class="btn-popup">Konfirmasi</a>
    <div class="cancel">
        <p class="opt"><a href="popup-login.php">Cancel</a></p> 
    </div>
    </div>
    <!-- verif email end-->
</body>
</html>