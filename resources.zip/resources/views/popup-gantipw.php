<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="pop-up.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <!-- ganti password start-->
    <div class="pop-up">
        <span class="close" onclick="closePopup()">&times;</span>
        <div class="np"><h1>Ubah Password</h1></div>
    <div class="isi">
        <div class="input">
            <input type="password" class="input" placeholder="Password baru">
        </div>
        <div class="input">
            <input type="password" class="input" placeholder="Ketik ulang password baru">
        </div>
    </div>
    <a href="popup-verif.php" class="btn-popup">Reset</a>
    <div class="cancel">
        <p class="opt"><a href="popup-login.php">Cancel</a></p> 
    </div>
    </div>
    <!-- ganti password end-->
</body>
</html>